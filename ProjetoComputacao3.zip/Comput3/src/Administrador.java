import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class Administrador extends Usuario{
	
	private int index = 0;
	private HashMap<Integer, String> nome;
	private HashMap<Integer, String> cpf;
	private HashMap<Integer, String> senha;

	
	public Administrador(ResultSet rs) throws SQLException
	{
		super(rs);
		 this.nome = new HashMap<>();
		 this.cpf = new HashMap<>();
		 this.senha = new HashMap<>();
		
		while(rs.next())
		{
			nome.put(index,rs.getString("nome"));
			cpf.put(index,rs.getString("cpf"));
			senha.put(index,rs.getString("senha"));
			index+=1;
		}

		
	}
	
	
	
}
