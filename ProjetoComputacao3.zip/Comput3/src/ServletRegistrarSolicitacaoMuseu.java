

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class ServletRegistrarSolicitacaoMuseu
 */
@WebServlet("/RegistrarNovaSolicitacaoMuseu")
public class ServletRegistrarSolicitacaoMuseu extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletRegistrarSolicitacaoMuseu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nome = request.getParameter("nome");
	    String data = request.getParameter("data");
	    String cidade = request.getParameter("cidade");
	    String estado = request.getParameter("estado");
	    String nome_gestor = request.getParameter("nome_gestor");
	    String cpf_gestor = request.getParameter("cpf_gestor");
	    String senha_gestor = request.getParameter("senha_gestor");
	    
	    try {

			MuseuMapper mapper = new MuseuMapper();
			mapper.registraSolicitacaoMuseuBD(nome, data, cidade, estado, nome_gestor, cpf_gestor, senha_gestor);
			
			String message = "Solicita��o feita com sucesso!";
        	response.sendRedirect("SolicitarMuseuPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
		
		    

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			String message = "Falha na cria��o da solicita��o!";
        	response.sendRedirect("SolicitarMuseuPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			e.printStackTrace();
		}
		
		
	}

}
