import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class Museu {
	private int index = 0;
	private HashMap<Integer, String> nome; 
	private HashMap<Integer, String> data_criacao; 
	private HashMap<Integer, String> cidade; 
	private HashMap<Integer, String> estado; 
	private HashMap<Integer, String> nome_gestor; 
	private HashMap<Integer, String> cpf_gestor; 
	private HashMap<Integer, String> senha_gestor; 
	private HashMap<Integer, Integer> solic;


	
	public Museu(ResultSet rs) throws SQLException
	{
		 this.nome = new HashMap<>();
		 this.data_criacao = new HashMap<>();
		 this.cidade = new HashMap<>();
		 this.estado = new HashMap<>();
		 this.nome_gestor = new HashMap<>();
		 this.cpf_gestor = new HashMap<>();
		 this.senha_gestor = new HashMap<>();
		 this.solic = new HashMap<>();
		 
		
		while(rs.next())
		{
			nome.put(index,rs.getString("nome"));
			data_criacao.put(index,rs.getString("data_criacao"));
			cidade.put(index,rs.getString("cidade"));
			estado.put(index,rs.getString("estado"));
			nome_gestor.put(index,rs.getString("nome_gestor"));
			cpf_gestor.put(index,rs.getString("cpf_gestor"));
			senha_gestor.put(index,rs.getString("senha_gestor"));
			solic.put(index,rs.getInt("solic"));
			
			index++;
		}
		
	}
	
	public ArrayList<ArrayList<String>> listarSolicitacoes(){
		
		ArrayList<ArrayList<String>> solicitacoes = new ArrayList<>();
		ArrayList<String> linha = new ArrayList<>();

		for(int i=0; i<index; i++)
		{
			if(solic.get(i).equals(1))
			{
				linha.add(nome.get(i));
				linha.add(data_criacao.get(i));
				linha.add(cidade.get(i));
				linha.add(estado.get(i));
				linha.add(nome_gestor.get(i));
				linha.add(cpf_gestor.get(i));
				linha.add(senha_gestor.get(i));
				solicitacoes.add(linha);
			}
		}
		return solicitacoes;
		
	}
	
}
