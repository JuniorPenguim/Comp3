import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MuseuMapper extends DataMapper{

	public ResultSet getTabelaMuseus() throws SQLException
	{
		Statement stm = this.c.createStatement();
		
		
		String query = "SELECT * FROM museus";
		stm.executeQuery(query);

		
		ResultSet rs = stm.getResultSet();


		return rs;
	}
	
	public void registraSolicitacaoMuseuBD(String nome, String data_criacao, String cidade, String estado, String nome_gestor, String cpf_gestor, String senha_gestor) throws SQLException
	{
		Statement stm = this.c.createStatement();
		int solic = 1;
		
		String query = "INSERT INTO museus VALUES(\n"
        + "\'"+nome+"\'"+",\n"
        + "\'"+data_criacao+"\'"+",\n"
        + "\'"+cidade+"\'"+",\n"
        + "\'"+estado+"\'"+",\n"
        + "\'"+nome_gestor+"\'"+",\n"
        + "\'"+cpf_gestor+"\'"+",\n"
        + "\'"+senha_gestor+"\'"+",\n"
        + ""+solic+""+"\n"
        + ")";
		
		stm.executeUpdate(query);
		
	}
	
	public void registraMuseuBD(String nome, String data_criacao, String cidade, String estado, String nome_gestor, String cpf_gestor, String senha_gestor, String nomeGestor, String cpfGestor, String senhaGestor) throws SQLException
	{
		Statement stm = this.c.createStatement();
		
		String query = "UPDATE museus\n"
		+ "SET nome_gestor=\'"+nomeGestor+"\', cpf_gestor=\'"+cpfGestor+"\', senha_gestor=\'"+senhaGestor+"\' , solic="+0+"\n"
		+ "WHERE nome=\'"+nome+"\' AND data_criacao=\'"+data_criacao+"\' AND cidade=\'"+cidade+"\' AND estado=\'"+estado+"\' AND nome_gestor=\'"+nome_gestor+"\' AND cpf_gestor=\'"+cpf_gestor+"\' AND senha_gestor=\'"+senha_gestor+"\'";
		
		stm.executeUpdate(query);
	}
	
}
