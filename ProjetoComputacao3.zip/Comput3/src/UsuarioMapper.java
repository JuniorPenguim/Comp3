import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class UsuarioMapper extends DataMapper{
	Connection c = getConnection();
	
	public ResultSet getTabelaUsuarios() throws SQLException
	{
		Statement stm = this.c.createStatement();
		
		
		String query = "SELECT * FROM usuarios";
		stm.executeQuery(query);

		
		ResultSet rs = stm.getResultSet();


		return rs;
	}
	
	public void registraUsuarioBD(String nome, String cpf, String senha) throws SQLException
	{
		Statement stm = this.c.createStatement();
				
		String query = "INSERT INTO usuarios VALUES(\n"
        + "\'"+cpf+"\'"+",\n"
        + "\'"+nome+"\'"+",\n"
        + "\'"+senha+"\'"+"\n"
        + ")";
		
		stm.executeUpdate(query);
		
	}
	
	public void removeUsuarioBD(String cpf) throws SQLException
	{
		Statement stm = this.c.createStatement();
		
		String query = "DELETE FROM usuarios\n"
		+ "WHERE cpf=\'"+cpf+"\'";
		
		stm.executeUpdate(query);
		
	}
	
}
