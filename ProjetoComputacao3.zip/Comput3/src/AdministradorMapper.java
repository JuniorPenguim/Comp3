import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class AdministradorMapper extends UsuarioMapper{
	
	public ResultSet getTabelaAdministradores() throws SQLException
	{
		Statement stm = this.c.createStatement();
		
		
		String query = "SELECT * FROM administradores";
		stm.executeQuery(query);

		
		ResultSet rs = stm.getResultSet();


		return rs;
	}
	
	public void registraAdministradorBD(String nome, String cpf, String senha) throws SQLException
	{
		Statement stm = this.c.createStatement();
				
		String query = "INSERT INTO administradores VALUES(\n"
        + "\'"+cpf+"\'"+",\n"
        + "\'"+nome+"\'"+",\n"
        + "\'"+senha+"\'"+"\n"
        + ")";
		
		stm.executeUpdate(query);
		
	}
}
