

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletCriarMuseu
 */
@WebServlet("/CriarMuseu")
public class ServletCriarMuseu extends HttpServlet {
	private ArrayList<ArrayList<String>> solicitacoes;
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCriarMuseu() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		try {
			
			MuseuMapper mapper = new MuseuMapper();
			Museu museu = new Museu(mapper.getTabelaMuseus());
			solicitacoes = museu.listarSolicitacoes();
			request.setAttribute("lista", solicitacoes);
			request.getRequestDispatcher("EscolherMuseus.jsp").forward(request, response);
			
			
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
	    String opcao = request.getParameter("opcao");
	    
		ArrayList<String> linha = solicitacoes.get(Integer.valueOf(opcao));
		
		request.setAttribute("dadosMuseu", linha);
		
		HttpSession session = request.getSession(true);
		
		session.setAttribute ("dadosMuseu",linha);
		request.setAttribute("flag", true);
		request.getRequestDispatcher("/CriarGestor").forward(request, response);
	
		
		

		
	}

}
