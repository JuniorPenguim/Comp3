import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DataMapper {
	private static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    private static final String URL = "jdbc:derby:C:\\Users\\caioc\\MyDB;create=true";
    //private static final String USER = "admin";
    //private static final String PASS = "2707";
    Connection c = getConnection();
    
    protected Connection getConnection(){
        
        
        try {
        	DriverManager.registerDriver(new org.apache.derby.jdbc.EmbeddedDriver());
            Class.forName(DRIVER);
            return java.sql.DriverManager.getConnection(URL);
            
        } catch (ClassNotFoundException | SQLException ex) {
            throw new RuntimeException("Erro na conec��o: ",ex);
        }}
    
    public String criarTabelas()
    {
    	String result = "";
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE usuarios(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null, PRIMARY KEY(cpf))";
    		stm.executeUpdate(query);
    		result = result+"Criada tabela usuarios<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela usuarios j� existe ou n�o p�de ser criada<br>";
    		System.out.println(ex);
        }
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE administradores(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null, PRIMARY KEY(cpf))";
    		stm.executeUpdate(query);
    		result = result+"Criada tabela administradores<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela administradores j� existe ou n�o p�de ser criada<br>";
    		System.out.println(ex);
        }
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE museus(nome varchar(20) not null, data_criacao varchar(20) not null, cidade varchar(20) not null,"
    		+"estado varchar(20) not null , nome_gestor varchar(20) not null, cpf_gestor varchar(20) not null , senha_gestor varchar(20) not null, solic int not null)";
    		stm.executeUpdate(query);
    		result = result+"Criada tabela museus<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela museus j� existe ou n�o p�de ser criada<br>";
    		System.out.println(ex);
        }
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE gestores(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null)";
    		stm.executeUpdate(query);
    		result = result+"Criada tabela gestores<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela gestorres j� existe ou n�o p�de ser criada<br>";
    		System.out.println(ex);
        }
    	return result;
    }
    
    public String excluirTabelas()
    {
    	String result = "";
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "DROP TABLE usuarios";
    		stm.executeUpdate(query);
    		result = result+"Tabela usuarios exclu�da<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela usuarios n�o existe ou n�o p�de ser exclu�da<br>";
    		System.out.println(ex);
        }
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "DROP TABLE administradores";
    		stm.executeUpdate(query);
    		result = result+"Tabela administradores exclu�da<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela administradores n�o existe ou n�o p�de ser criada<br>";
    		System.out.println(ex);
        }
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "DROP TABLE museus";
    		stm.executeUpdate(query);
    		result = result+"Tabela museus exclu�da<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela museus n�o existe ou n�o p�de ser criada<br>";
    		System.out.println(ex);
        }
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "DROP TABLE gestores";
    		stm.executeUpdate(query);
    		result = result+"Tabela gestores exclu�da<br>";
    	}
    	catch (SQLException ex) {
    		result = result+"Tabela gestores n�o existe ou n�o p�de ser criada<br>";
    		System.out.println(ex);
        }
    	return result;
    }
    
    public String excluirTabela(String tabela)
    {
    	
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "DROP TABLE "+tabela;
    		stm.executeUpdate(query);
    		return "Tabela "+tabela+" exclu�da<br>";
    	}
    	
    	catch (SQLException ex) {
    		System.out.println(ex);
    		return "Tabela "+tabela+" n�o existe ou n�o p�de ser exclu�da<br>";
        }
    	
    }
    
    public String criarTabela(String tabela)
    {
    	if(tabela.equals("usuarios"))
    	{
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE usuarios(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null, PRIMARY KEY(cpf))";
    		stm.executeUpdate(query);
    		return "Tabela "+tabela+" criada<br>";
    	}
    	catch (SQLException ex) {
    		System.out.println(ex);
    		return "Tabela "+tabela+" j� existe ou n�o p�de ser criada<br>";
        }
    	}
    	
    	else if(tabela.equals("administradores"))
    	{
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE administradores(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null, PRIMARY KEY(cpf))";
    		stm.executeUpdate(query);
    		return "Tabela "+tabela+" criada<br>";
    	}
    	catch (SQLException ex) {
    		System.out.println(ex);
    		return "Tabela "+tabela+" j� existe ou n�o p�de ser criada<br>";
        }
    	}
    	
    	else if(tabela.equals("museus"))
    	{
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE museus(nome varchar(20) not null, data_criacao varchar(20) not null, cidade varchar(20) not null,"
    		+"estado varchar(20) not null , nome_gestor varchar(20) not null, cpf_gestor varchar(20) not null , senha_gestor varchar(20) not null, solic int not null)";
    		stm.executeUpdate(query);
    		return "Tabela "+tabela+" criada<br>";
    	}
    	catch (SQLException ex) {
    		System.out.println(ex);
    		return "Tabela "+tabela+" j� existe ou n�o p�de ser criada<br>";
        }
    	}
    	
    	else if(tabela.equals("gestores"))
    	{
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE gestores(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null)";
    		stm.executeUpdate(query);
    		return "Tabela "+tabela+" criada<br>";
    	}
    	catch (SQLException ex) {
    		System.out.println(ex);
    		return "Tabela "+tabela+" j� existe ou n�o p�de ser criada<br>";
        }
    	}
    	return "";
    }
    	
    	
}
