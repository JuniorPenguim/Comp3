import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class GestorMapper extends DataMapper{
	public ResultSet getTabelaGestores() throws SQLException
	{
		Statement stm = this.c.createStatement();
		
		
		String query = "SELECT * FROM gestores";
		stm.executeQuery(query);

		
		ResultSet rs = stm.getResultSet();


		return rs;
	}
	
	public void registraGestorBD(String nome, String cpf, String senha) throws SQLException
	{
		Statement stm = this.c.createStatement();
				
		String query = "INSERT INTO gestores VALUES(\n"
        + "\'"+cpf+"\'"+",\n"
        + "\'"+nome+"\'"+",\n"
        + "\'"+senha+"\'"+"\n"
        + ")";
		
		stm.executeUpdate(query);
		
	}
}
