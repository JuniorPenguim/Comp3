

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletCriarGestor
 */
@WebServlet("/CriarGestor2")
public class ServletCriarGestor2 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletCriarGestor2() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		HttpSession session = request.getSession(false);
		
		String nome_gestor = (String)session.getAttribute("nome_gestor");
		String cpf_gestor = (String)session.getAttribute("cpf_gestor");
		String senha_gestor = (String)session.getAttribute("senha_gestor");
		
		GestorMapper mapper2 = new GestorMapper();
		PrintWriter out = response.getWriter();
		
		@SuppressWarnings("unchecked")
		ArrayList<String> linha = (ArrayList<String>)session.getAttribute("dadosMuseu");
		
		try {
			if(session.getAttribute("message") != null && session.getAttribute("message").equals("Confirma"))
			{
				
			mapper2.registraGestorBD(nome_gestor, cpf_gestor, senha_gestor);
			MuseuMapper mapper3 = new MuseuMapper();
			mapper3.registraMuseuBD(linha.get(0), linha.get(1), linha.get(2), linha.get(3), linha.get(4), linha.get(5), linha.get(6), nome_gestor, cpf_gestor, senha_gestor);
			UsuarioMapper mapper = new UsuarioMapper();
			mapper.removeUsuarioBD(cpf_gestor);
			
			out.println("<h1>Museu criado com sucesso</h1><br>");
			out.print("<br><form action=\"index.jsp\" method=\"GET\"><input type=\"submit\" value=\"Voltar ao in�cio\" /></form>");
			
			}
			else
			{
				session.setAttribute("message", "Confirma");
	    		out.print("<br><form action=\"CriarGestor2\" method=\"GET\"><input type=\"submit\" value=\"Confirma cria��o de museu\" /></form>");
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String nome_gestor = request.getParameter("nomeGestor");
		String cpf_gestor = request.getParameter("cpfGestor");
		String senha_gestor = request.getParameter("senhaGestor");
		
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession(false);
		
		session.setAttribute("nome_gestor", nome_gestor);
		session.setAttribute("cpf_gestor", cpf_gestor);
		session.setAttribute("senha_gestor", senha_gestor);
		
		try {
			UsuarioMapper mapper = new UsuarioMapper();
			Usuario user = new Usuario(mapper.getTabelaUsuarios());
			String result = user.consultaSeExiste(cpf_gestor);
			
			if(result.equals("Nao existe"))
			{
				if(session.getAttribute("message") != null && session.getAttribute("message").equals("Confirma"))
				{
				GestorMapper mapper2 = new GestorMapper();
				@SuppressWarnings("unchecked")
				ArrayList<String> linha = (ArrayList<String>)session.getAttribute("dadosMuseu");
					
				mapper2.registraGestorBD(nome_gestor, cpf_gestor, senha_gestor);
				MuseuMapper mapper3 = new MuseuMapper();
				
				mapper3.registraMuseuBD(linha.get(0), linha.get(1), linha.get(2), linha.get(3), linha.get(4), linha.get(5), linha.get(6), nome_gestor, cpf_gestor, senha_gestor);
				out.println("<h1>Museu criado com sucesso</h1><br>");
				out.print("<br><form action=\"index.jsp\" method=\"GET\"><input type=\"submit\" value=\"Voltar ao in�cio\" /></form>");
				}
				else
				{
					session.setAttribute("message", "Confirma");
		    		out.print("<br><form action=\"CriarGestor2\" method=\"GET\"><input type=\"submit\" value=\"Confirma cria��o de museu\" /></form>");
				}
				
				
				
			}
			else
			{
				out.println("<br><h2>J� existe um usu�rio com esse CPF. Deseja Utiliz�-lo?</h2><br>");
				session.setAttribute("nome_gestor", nome_gestor);
				session.setAttribute("cpf_gestor", cpf_gestor);
				session.setAttribute("senha_gestor", senha_gestor);
	    		out.print("<br><form action=\"CriarGestor2\" method=\"GET\"><input type=\"submit\" value=\"Criar com usu�rio\" /></form>");
	    		
			}
			
			
		} catch (SQLException e) {
			System.out.println(e);
			e.printStackTrace();
		}

	}

}
