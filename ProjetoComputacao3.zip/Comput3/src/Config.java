

import java.io.IOException;
import java.net.URLEncoder;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Inicializar
 */
@WebServlet("/Config")
public class Config extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Config() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		DataMapper mapper = new DataMapper();
		String opcao = request.getParameter("opcao");
		String message = "";
		
		if(opcao.equals("Criar tabelas"))
		{
			message = mapper.criarTabelas();
		}
		else if(opcao.equals("Excluir tabelas"))
		{
			message = mapper.excluirTabelas();
		}
		else if(opcao.equals("Criar"))
		{
			String tabela = request.getParameter("nomeTabela");
			message = mapper.criarTabela(tabela);
		}
		else if(opcao.equals("Excluir"))
		{
			String tabela = request.getParameter("nomeTabela");
			message = mapper.excluirTabela(tabela);
		}
		
		response.sendRedirect("index.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
		
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cod = request.getParameter("cod");
		if(cod.contentEquals("admin"))
		{
			request.setAttribute("flag", "1");
			request.getRequestDispatcher("ConfigPag.jsp").forward(request, response);
		}
		else
			response.sendRedirect("ConfigPag1.jsp?message=" + URLEncoder.encode("C�digo incorreto!", "UTF-8"));
	}
}
