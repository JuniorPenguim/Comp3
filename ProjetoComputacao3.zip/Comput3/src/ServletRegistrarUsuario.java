
import java.io.IOException;
import java.net.URLEncoder;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletRegistrarUsuario
 */
@WebServlet("/RegistrarNovoUsuario")
public class ServletRegistrarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletRegistrarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nome = request.getParameter("usuario");
	    String senha = request.getParameter("senha");
	    String cpf = request.getParameter("cpf");
		
		
		try {

			UsuarioMapper mapper = new UsuarioMapper();

			Usuario user = new Usuario(mapper.getTabelaUsuarios());
			
			AdministradorMapper mapper2 = new AdministradorMapper();

			Administrador admin = new Administrador(mapper2.getTabelaAdministradores());

			String result = user.consultaSeExiste(cpf);
			
			String result2 = admin.consultaSeExiste(cpf);
			
			
			if(result.equals("Nao existe") && result2.equals("Nao existe"))
			{
				mapper.registraUsuarioBD(nome, cpf, senha);
				HttpSession session = request.getSession(true);
		         
			    session.setAttribute ("nome",nome);
			    session.setAttribute ("cpf",cpf);
			    session.setAttribute ("permissao","user");
			    
			    
			    request.getRequestDispatcher("home.jsp").forward(request, response);
			}
			else if(result.equals("Existe"))
			{
				String message = "CPF j� cadastrado!";
	        	response.sendRedirect("RegistrarUsuarioPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			else if(result2.equals("Existe"))
			{
				String message = "CPF j� cadastrado!";
	        	response.sendRedirect("RegistrarUsuarioPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			else if(result.equals("Cpf invalido"))
			{
				String message = "CPF inv�lido!";
	        	response.sendRedirect("RegistrarUsuarioPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			
 
		    
		    

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

}
