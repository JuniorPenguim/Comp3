

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletIdentificarUsuario
 */
@WebServlet("/IdentificarUsuario")
public class ServletIdentificarUsuario extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletIdentificarUsuario() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	    String senha = request.getParameter("senha");
	    String cpf = request.getParameter("cpf");
	    
	    try {

			UsuarioMapper mapper = new UsuarioMapper();
			AdministradorMapper mapper2 = new AdministradorMapper();

			Usuario user = new Usuario(mapper.getTabelaUsuarios());
			Administrador admin = new Administrador(mapper2.getTabelaUsuarios());

			String result = user.consultaSenha(cpf, senha);
			String result2 = admin.consultaSenha(cpf, senha);
			
			
			if(result.equals("Nao existe") && result2.equals("Nao existe"))
			{
				String message = "Cadastro n�o existe!";
				response.sendRedirect("index.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			else if(result.equals("Nao existe") && !result2.equals("Nao existe"))
			{
				request.getRequestDispatcher("IdentificarAdmin").forward(request, response);
			}
			
			else if(result.equals("Nao existe")) {
				String message = "Cadastro n�o existe!";
				response.sendRedirect("index.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
				
			else if(result.equals("Senha incorreta"))
			{
				String message = "Senha incorreta!";
				response.sendRedirect("index.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			else if(result.equals("Cpf invalido"))
			{
				String message = "CPF inv�lido!";
				response.sendRedirect("index.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			else if(result.equals("Senha correta"))
			{
				String nome = user.getNome();
				HttpSession session = request.getSession(true);
         
				session.setAttribute ("nome",nome);
				session.setAttribute ("cpf",cpf);
				session.setAttribute ("permissao","user");
		    
				//response.sendRedirect("home.jsp?dados=" + URLEncoder.encode(nome+"<br>"+cpf, "UTF-8"));
				request.getRequestDispatcher("home.jsp").forward(request, response);
			}
			else
			{
				String message = "Erro gen�rico";
				response.sendRedirect("index.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			
			
		    

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
	}

}
