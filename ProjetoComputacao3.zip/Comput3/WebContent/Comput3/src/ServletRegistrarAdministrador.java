

import java.io.IOException;
import java.net.URLEncoder;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ServletRegistrarAdministrador
 */
@WebServlet("/RegistrarNovoAdministrador")
public class ServletRegistrarAdministrador extends HttpServlet{
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ServletRegistrarAdministrador() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String nome = request.getParameter("usuario");
	    String senha = request.getParameter("senha");
	    String cpf = request.getParameter("cpf");
	    String codigo = request.getParameter("codigo");
		
	    
		if(codigo.equals("admin"))
		{
		try {

			AdministradorMapper mapper = new AdministradorMapper();

			Administrador user = new Administrador(mapper.getTabelaUsuarios());

			String result = user.consultaSeExiste(cpf);
			
			if(result.equals("Nao existe"))
			{
				mapper.registraUsuarioBD(nome, cpf, senha);
				HttpSession session = request.getSession(true);
		         
			    session.setAttribute ("nome",nome);
			    session.setAttribute ("cpf",cpf);
			    session.setAttribute ("permissao","admin");
			    
			    //response.sendRedirect("home.jsp?dados=" + URLEncoder.encode(nome+"<br>"+cpf, "UTF-8"));
			    
			    request.getRequestDispatcher("home.jsp").forward(request, response);
			}
			else if(result.equals("Existe"))
			{
				String message = "CPF j� cadastrado!";
	        	response.sendRedirect("RegistrarAdminPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			else if(result.equals("Cpf invalido"))
			{
				String message = "CPF inv�lido!";
	        	response.sendRedirect("RegistrarAdminPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
			}
			
 
		    
		    

			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		}
		else
		{
			String message = "C�digo de super usu�rio inv�lido!";
        	response.sendRedirect("RegistrarAdminPag.jsp?message=" + URLEncoder.encode(message, "UTF-8"));
		}
		
		
	}

	

}
