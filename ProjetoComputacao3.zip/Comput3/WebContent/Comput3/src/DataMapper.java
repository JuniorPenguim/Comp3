import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DataMapper {
	private static final String DRIVER = "org.apache.derby.jdbc.EmbeddedDriver";
    private static final String URL = "jdbc:derby:C:\\Users\\caioc\\MyDB;create=true";
    //private static final String USER = "admin";
    //private static final String PASS = "2707";
    Connection c = getConnection();
    
    protected Connection getConnection(){
        
        
        try {
        	DriverManager.registerDriver(new org.apache.derby.jdbc.EmbeddedDriver());
            Class.forName(DRIVER);
            return java.sql.DriverManager.getConnection(URL);
            
        } catch (ClassNotFoundException | SQLException ex) {
            throw new RuntimeException("Erro na conec��o: ",ex);
        }}
    
    public void criaTabelas()
    {
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE usuarios(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null, PRIMARY KEY(cpf))";
    		stm.executeUpdate(query);
    	}
    	catch (SQLException ex) {
    		System.out.println(ex);
        }
    	try {
    		Statement stm = this.c.createStatement();
    		String query = "CREATE TABLE administradores(cpf varchar(20) not null, nome varchar(20) not null, senha varchar(20) not null, PRIMARY KEY(cpf))";
    		stm.executeUpdate(query);
    	}
    	catch (SQLException ex) {
    		System.out.println(ex);
        }
    }
}
