import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;

public class Usuario {
	//private ArrayList<String> nome;
	//private ArrayList<String> cpf;
	//private ArrayList<String> senha;
	private int index = 0;
	private HashMap<Integer, String> nome = new HashMap<>();
	private HashMap<Integer, String> cpf = new HashMap<>();
	private HashMap<Integer, String> senha = new HashMap<>();
	private int atualIndex = 0;

	
	
	public Usuario(ResultSet rs) throws SQLException
	{
		//this.nome = new ArrayList<String>();
		//this.cpf = new ArrayList<String>();
		//this.senha = new ArrayList<String>();
		 this.nome = new HashMap<>();
		 this.cpf = new HashMap<>();
		 this.senha = new HashMap<>();
		
		while(rs.next())
		{
			//this.nome.add(rs.getString("nome")+";"+Integer.toString(index));
			nome.put(index,rs.getString("nome"));
			cpf.put(index,rs.getString("cpf"));
			senha.put(index,rs.getString("senha"));
			//this.cpf.add(rs.getString("cpf")+";"+Integer.toString(index));
			//this.senha.add(rs.getString("senha")+";"+Integer.toString(index));
			index+=1;
		}

		
	}
	
	public String consultaSeExiste(String cpfBuscar)
	{
		if(this.verificaCpfValido(cpfBuscar))
		{
			Boolean resp = buscaString(this.cpf, cpfBuscar);
			if(resp == false)
				return "Nao existe";
			else
				return "Existe";
		}
		else
			return "Cpf invalido";
	}
	
	private Boolean verificaCpfValido(String cpf)
	{
		return true;
		
	}
	
	private boolean buscaString(HashMap<Integer, String> cpf, String busca) {
        for (int i = 0; i < cpf.size(); i++) {
            if (cpf.get(i).contains(busca)) {
            	this.atualIndex = i;
                return true;
            }
        }
        return false;
    }
	
	public String getNome()
	{
		return nome.get(atualIndex);
	}
	
	
	public String consultaSenha(String cpfBuscar, String senhaVerificar)
	{
		if(this.verificaCpfValido(cpfBuscar))
		{
			Boolean resp = buscaString(this.cpf, cpfBuscar);
			if(resp == false)
				return "Nao existe";
			else
			{
				if(senhaVerificar.equals(this.senha.get(atualIndex)))
				{
					return "Senha correta";
				}
				else
				{
					return "Senha incorreta";
				}
			}
		}
		else
			return "Cpf invalido";
	}
	
}
