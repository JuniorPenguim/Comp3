import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

public class Administrador extends Usuario{
	
	private int index = 0;
	private HashMap<Integer, String> nome = new HashMap<>();
	private HashMap<Integer, String> cpf = new HashMap<>();
	private HashMap<Integer, String> senha = new HashMap<>();
	private int atualIndex = 0;

	
	public Administrador(ResultSet rs) throws SQLException
	{
		super(rs);
		//this.nome = new ArrayList<String>();
		//this.cpf = new ArrayList<String>();
		//this.senha = new ArrayList<String>();
		 this.nome = new HashMap<>();
		 this.cpf = new HashMap<>();
		 this.senha = new HashMap<>();
		
		while(rs.next())
		{
			//this.nome.add(rs.getString("nome")+";"+Integer.toString(index));
			nome.put(index,rs.getString("nome"));
			cpf.put(index,rs.getString("cpf"));
			senha.put(index,rs.getString("senha"));
			//this.cpf.add(rs.getString("cpf")+";"+Integer.toString(index));
			//this.senha.add(rs.getString("senha")+";"+Integer.toString(index));
			index+=1;
		}

		
	}
	
	
	
}
