import static org.junit.Assert.assertEquals;

import java.sql.SQLException;
import java.util.ArrayList;

import org.junit.jupiter.api.Test;

class MuseuTest {

	@Test
	void test() throws SQLException {
		
		MockResultSetMuseu mock = new MockResultSetMuseu();
		TesteMuseu museu = new TesteMuseu(mock);
		
		ArrayList<ArrayList<String>> conjuntoTeste = museu.listarSolicitacoes();
		ArrayList<String> linhaTtens = conjuntoTeste.get(0);

		
		String nome = linhaTtens.get(0);

		assertEquals("Pedro", nome);		
		
	}

}