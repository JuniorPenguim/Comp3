
public class MockResultSet {

	
	
	private int i=-1;

	String set [][] = {{"Pedro","Joao","Mario"},
						{"44770273894","456","789"},
						{"teste1","teste2","teste3"}};
	public boolean next ()
	{

		this.i++;
		if(i<3) 
			return true;
		else
			return false;
	}

	
	public String getString(String teste)
	{
		switch (teste) {
		case "nome":
				return set[0][i];
		case "cpf":
				return set[1][i];
		case "senha":
				return set[2][i];
		default:
				break;
				
		
	}
	
	return null;
	
	}
	

	
}

