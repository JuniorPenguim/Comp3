public class MockResultSetMuseu {

	private int i=-1;

	String set [][] = {{"Pedro","Joao","Mario"},
						{"27/06/2019","21/05/2019","20/02/2019"},
						{"Nova Iguacu","Queimados","Rio de Janeiro"},
						{"Rio de Janeiro", "Rio de Janeiro","Rio de Janeiro"},
						{"Fabio", "Caio", "Ingrid"},
						{"47770273894", "12345678910", "45678901239"},
						{"123","456","789"},
						{"1", "1", "0"}
							};
						
	public boolean next ()
	{

		this.i++;
		if(i<2) 
			return true;
		else
			return false;
	}
	
	

	
	public String getString(String teste)
	{
		switch (teste)
		{
		case "nome":
				return set[0][i];
		case "data_criacao":
				return set[1][i];
		case "cidade":
				return set[2][i];
		case "estado":
				return set[3][i];
		case "nome_gestor":
				return set[4][i];
		case "cpf_gestor":
				return set[5][i];
		case "senha_gestor":
				return set[6][i];		
		default:
				break;				
		
		}	
	
		
	return null;
	
	}
	
	public int getInt(String valor) {
		
		if(valor=="solic")
		{ 
			return Integer.parseInt(set[7][i]);
		}
		
		return -1;
		
	}
	
	
}
