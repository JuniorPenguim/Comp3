import static org.junit.jupiter.api.Assertions.*;

import java.sql.SQLException;

import org.junit.jupiter.api.Test;

class UsuarioTest {

	@Test
	void testaCPFAcerto() throws SQLException {		
		
		
		MockResultSet mock = new MockResultSet();
		TesteUsuario usuario = new TesteUsuario(mock);
		
		String cpf = "44770273894";
		String condicao = usuario.consultaSeExiste(cpf);
		
		assertEquals("Existe", condicao);
		
		
	}
	
	@Test
	void testaCPFErro() throws SQLException {		
		
		
		MockResultSet mock = new MockResultSet();
		TesteUsuario usuario = new TesteUsuario(mock);
		
		String cpf = "13549993714";
		String condicao = usuario.consultaSeExiste(cpf);
		
		assertEquals("Nao existe", condicao);
		
	
	}
	@Test
	void testaSenhaCorreta() throws SQLException{
		
		
		MockResultSet mock = new MockResultSet();
		TesteUsuario usuario = new TesteUsuario(mock);
		String cpf = "44770273894";
		String senha = "teste1";
		String condicao = usuario.consultaSenha(cpf, senha);
		
		assertEquals("Senha correta", condicao);
		
	}
	

}
