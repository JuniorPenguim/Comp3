
	import java.sql.SQLException;
	import java.util.HashMap;

	public class TesteUsuario {
		private int index = 0;
		private HashMap<Integer, String> nome;
		private HashMap<Integer, String> cpf;
		private HashMap<Integer, String> senha;
		private int atualIndex = 0;
		private static final int[] pesoCPF = {11, 10, 9, 8, 7, 6, 5, 4, 3, 2};
		
		
		public TesteUsuario(MockResultSet rs) throws SQLException
		{
			 this.nome = new HashMap<>();
			 this.cpf = new HashMap<>();
			 this.senha = new HashMap<>();
			
			while(rs.next())
			{
				nome.put(index,rs.getString("nome"));
				cpf.put(index,rs.getString("cpf"));
				senha.put(index,rs.getString("senha"));
				index+=1;
			}

			
		}
		
		public String consultaSeExiste(String cpfBuscar)
		{
			if(this.verificaCpfValido(cpfBuscar))
			{
				Boolean resp = buscaString(this.cpf, cpfBuscar);
				if(resp == false)
					return "Nao existe";
				else
					return "Existe";
			}
			else
				return "Cpf invalido";
		}
		
		private Boolean verificaCpfValido(String cpf)
		{
			if ((cpf==null) || (cpf.length()!=11)) return false;

		      Integer digito1 = calcularDigito(cpf.substring(0,9), pesoCPF);
		      Integer digito2 = calcularDigito(cpf.substring(0,9) + digito1, pesoCPF);
		      return cpf.equals(cpf.substring(0,9) + digito1.toString() + digito2.toString());
		}
		
		 private static int calcularDigito(String str, int[] peso) {
		      int soma = 0;
		      for (int indice=str.length()-1, digito; indice >= 0; indice-- ) {
		         digito = Integer.parseInt(str.substring(indice,indice+1));
		         soma += digito*peso[peso.length-str.length()+indice];
		      }
		      soma = 11 - soma % 11;
		      return soma > 9 ? 0 : soma;
		   }

		private boolean buscaString(HashMap<Integer, String> cpf, String busca) {
	        for (int i = 0; i < cpf.size(); i++) {
	            if (cpf.get(i).contains(busca)) {
	            	this.atualIndex = i;
	                return true;
	            }
	        }
	        return false;
	    }
		
		public String getNome()
		{
			return nome.get(atualIndex);
		}
		
		
		public String consultaSenha(String cpfBuscar, String senhaVerificar)
		{
			if(this.verificaCpfValido(cpfBuscar))
			{
				Boolean resp = buscaString(this.cpf, cpfBuscar);
				if(resp == false)
					return "Nao existe";
				else
				{
					if(senhaVerificar.equals(this.senha.get(atualIndex)))
					{
						return "Senha correta";
					}
					else
					{
						return "Senha incorreta";
					}
				}
			}
			else
				return "Cpf invalido";
		}
		
	}
	